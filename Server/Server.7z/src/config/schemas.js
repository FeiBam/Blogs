const Joi = require('@hapi/joi')

const schemas = {
    Article:
        Joi.object({
            Title:Joi.string()
                .required(),
            Introduction:Joi.string()
                .required(),
            Subject:Joi.string()
                .required(),
            Tags:Joi.array().items(
                Joi.object({
                    Name:Joi.string()
                        .required()
                })
            ),
            Creator:Joi.object({
                Name:Joi.string()
                    .required(),
                Date:Joi.string()
            })
        }),
    Tag:
        Joi.object({
            TagName:Joi.string()
                .required(),

        }),
    FriendLinks:
        Joi.object({
            Name:Joi.string()
                .required(),
            Img:Joi.string()
                .required(),
            Url:Joi.string()
                .required()
        }),
    Account:
        Joi.object({
            Name:Joi.string()
                .required(),
            PassWord:Joi.string()
                .required(),
            Img:Joi.string()
                .required()
        }),
    Login:
        Joi.object({
            UserName:Joi.string()
                .required(),
            PassWord:Joi.string()
                .required()
        })

}


module.exports = schemas