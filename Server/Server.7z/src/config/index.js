

const path = require('path')

module.exports = {
    secret:{
        JwtHead:{
            "alg": "HS256",
            "typ": "JWT"
        },
        Salt:'@%SDF124ewf@#%!@=12#!@2sdsdf[;342nn',
        Crypto:'SHA256',
        TokenValidPeriod:3 * 60 * 60 * 1000,
    },//密码加密方式
    defaultAccount:{
        Name:'root',
        PassWord: '12345678'
    },
    port:8000,//服务器监听端口
    logPath:path.resolve(__dirname,'../logs'),//日志输出文件夹
    routerPath:path.resolve(__dirname,'../routes'),//路由文件夹
    installRouter:[
        {
            url:'/blog',
            routerName:'blog',
        },
        {
            url: '/admin',
            routerName: 'admin'
        }
    ],//已经安装的路由
    mysql:{
        database:'myblog',
        port:3306,
        username:'feibam',
        password:'FeiBam_Mysql20020201',
        host:'rm-bp1kw1hl03ge751qbao.mysql.rds.aliyuncs.com'
    },//数据库相关
    select:{
        blog:{
            pageArticleLimit:5,
            withTag:true
        },
    }
}