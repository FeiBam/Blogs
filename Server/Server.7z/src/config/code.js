const Codes = {
    SUCCESS:1,
    USER_NOT_FOUND:4004,
    PASSWORD_OR_USER_ERR:4001,
    PARAMS_ERROR:4000,
    ACCOUNT_UN_ACTIVE:4003,
    TAG_RECREATE:2000
}


module.exports = Codes