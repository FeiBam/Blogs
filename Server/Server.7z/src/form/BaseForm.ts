const BlogDb = require('../db/index')

class BaseForm {
    public Transaction
     constructor(Context: any) {

    }
}